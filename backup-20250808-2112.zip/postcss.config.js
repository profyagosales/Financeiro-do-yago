export default {
  plugins: {
tailwindcss: {},            // ✅ plugin correto para v3
autoprefixer: {},
  },
};