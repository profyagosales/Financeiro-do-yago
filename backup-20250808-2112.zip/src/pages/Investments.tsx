import { useInvestments } from '../hooks/useInvestments';
import { useState } from 'react';

export default function Investments() {
  const { data, add } = useInvestments();
  const [form, setForm] = useState({ asset:'', type:'stock', quantity:0, price:0, date:'' });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Investimentos</h1>

      {/* formulário simples de teste */}
      <form onSubmit={e => { e.preventDefault(); add(form as any); }}>
        <input placeholder="Ativo"    onChange={e=>setForm({...form, asset:e.target.value})}/>
        <input placeholder="Tipo"     onChange={e=>setForm({...form, type:e.target.value})}/>
        <input placeholder="Qtd" type="number" step="0.01"
               onChange={e=>setForm({...form, quantity:+e.target.value})}/>
        <input placeholder="Preço" type="number" step="0.01"
               onChange={e=>setForm({...form, price:+e.target.value})}/>
        <input type="date"
               onChange={e=>setForm({...form, date:e.target.value})}/>
        <button>Salvar</button>
      </form>

      {/* listagem */}
      <table><tbody>
        {data.map(i=>(
          <tr key={i.id}><td>{i.asset}</td><td>{i.quantity}</td></tr>
        ))}
      </tbody></table>
    </div>
  );
}