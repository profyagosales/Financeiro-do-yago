export default function RendaFixa() {
  return <h1 className="text-2xl font-bold">📈 Investimentos - Renda Fixa</h1>;
}