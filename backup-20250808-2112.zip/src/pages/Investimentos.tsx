import { useMemo, useState } from 'react';
import dayjs from 'dayjs';
import 'dayjs/locale/pt-br';

import { PageHeader } from '@/components/PageHeader';
import { MotionCard } from '@/components/ui/MotionCard';
import { AnimatedNumber } from '@/components/ui/AnimatedNumber';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';

import { useInvestments, type Investment } from '@/hooks/useInvestments';
import ModalInvestimento from '@/components/ModalInvestimento';

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { colorForCategory } from '@/lib/palette';
import { toast } from 'sonner';

dayjs.locale('pt-br');

export default function Investimentos() {
  const [mes, setMes] = useState(() => dayjs().format('YYYY-MM'));
  const [modal, setModal] = useState(false);
  const [editando, setEditando] = useState<Investment | null>(null);

  const { data, loading, error, add, update, remove } = useInvestments(mes);

  // KPIs
  const patrimonio = useMemo(() =>
    data.reduce((s, i) => s + i.quantity * i.price, 0), [data]);

  const aportesMes = useMemo(() =>
    data.reduce((s, i) => s + i.quantity * i.price, 0), [data]);

  const qtdAtivos = useMemo(() => new Set(data.map(d => d.asset)).size, [data]);

  // donut por tipo
  const byType = useMemo(() => {
    const m = data.reduce<Record<string, number>>((acc, i) => {
      const v = i.quantity * i.price;
      acc[i.type] = (acc[i.type] ?? 0) + v;
      return acc;
    }, {});
    return Object.entries(m).map(([name, value]) => ({ name, value }));
  }, [data]);

  const abrirNovo = () => { setEditando(null); setModal(true); };
  const abrirEditar = (i: Investment) => { setEditando(i); setModal(true); };

  const salvar = async (payload: Omit<Investment,'id'|'user_id'>) => {
    try {
      if (editando) { await update(editando.id, payload); toast.success('Investimento atualizado'); }
      else { await add(payload); toast.success('Investimento adicionado'); }
      setModal(false);
    } catch (e: any) { toast.error(e?.message || 'Erro ao salvar'); }
  };

  const excluir = async (id: number) => {
    try { await remove(id); toast.success('Excluído'); }
    catch (e: any) { toast.error(e?.message || 'Erro ao excluir'); }
  };

  // meses para o filtro
  const mesesUnicos = useMemo(() => {
    const set = new Set(data.map(d => d.date.slice(0,7)));
    set.add(mes);
    return Array.from(set).sort().reverse();
  }, [data, mes]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Investimentos"
        subtitle="Patrimônio, aportes e distribuição por classe"
      >
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-[220px]">
            <span className="mb-1 block text-xs text-emerald-100/90">Mês</span>
            <Select value={mes} onValueChange={setMes}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Selecione o mês" /></SelectTrigger>
              <SelectContent>
                {mesesUnicos.map(m => (
                  <SelectItem key={m} value={m}>{dayjs(m + '-01').format('MMMM/YYYY')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={abrirNovo}>Novo investimento</Button>
        </div>
      </PageHeader>

      {/* KPIs */}
      <section className="grid gap-4 sm:grid-cols-3">
        <MotionCard><div><div className="text-sm text-slate-500">Patrimônio</div><AnimatedNumber value={patrimonio} /></div></MotionCard>
        <MotionCard><div><div className="text-sm text-slate-500">Aportes no mês</div><AnimatedNumber value={aportesMes} /></div></MotionCard>
        <MotionCard><div><div className="text-sm text-slate-500">Ativos</div><div className="text-2xl font-semibold">{qtdAtivos}</div></div></MotionCard>
      </section>

      {/* gráfico por tipo */}
      <div className="rounded-xl border bg-white dark:bg-slate-900 p-4">
        <h3 className="font-medium mb-3">Distribuição por tipo</h3>
        <div className="h-[320px]">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={byType} dataKey="value" nameKey="name" innerRadius={70} outerRadius={100} paddingAngle={2}>
                {byType.map(entry => <Cell key={entry.name} fill={colorForCategory(entry.name)} />)}
              </Pie>
              <Tooltip formatter={(v: any) => `R$ ${Number(v).toFixed(2)}`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* tabela simples */}
      <div className="rounded-xl border bg-white dark:bg-slate-900 p-4">
        <h3 className="font-medium mb-3">Lançamentos</h3>
        {loading && <p>Carregando…</p>}
        {error && <p className="text-red-600">{error}</p>}
        {!loading && !data.length && <p className="text-sm text-slate-500">Sem lançamentos.</p>}
        {!!data.length && (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="text-left text-slate-500">
                <tr><th className="py-2">Data</th><th>Ativo</th><th>Tipo</th><th>Qtd</th><th>Preço</th><th>Total</th><th></th></tr>
              </thead>
              <tbody>
                {data.map(i => (
                  <tr key={i.id} className="border-t">
                    <td className="py-2">{dayjs(i.date).format('DD/MM')}</td>
                    <td>{i.asset}</td>
                    <td>{i.type}</td>
                    <td>{i.quantity}</td>
                    <td>R$ {i.price.toFixed(2)}</td>
                    <td>R$ {(i.quantity * i.price).toFixed(2)}</td>
                    <td className="text-right space-x-2">
                      <Button variant="outline" size="sm" onClick={() => abrirEditar(i)}>Editar</Button>
                      <Button variant="destructive" size="sm" onClick={() => excluir(i.id)}>Excluir</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* modal */}
      <ModalInvestimento
        open={modal}
        onClose={() => setModal(false)}
        initialData={editando && {
          date: editando.date, asset: editando.asset, type: editando.type,
          quantity: editando.quantity, price: editando.price
        }}
        onSubmit={salvar}
      />
    </div>
  );
}