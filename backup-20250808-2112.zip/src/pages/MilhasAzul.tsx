import MilhasLivelo from './MilhasLivelo';
export default function MilhasAzul() {
  return <MilhasLivelo />;
}