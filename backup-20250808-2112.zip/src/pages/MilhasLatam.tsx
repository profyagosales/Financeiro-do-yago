import MilhasLivelo from './MilhasLivelo';
export default function MilhasLatam() {
  // Reuso rápido: mesma página, trocando somente o título/badge
  // Para personalizar (cores/regras), podemos separar depois.
  // Como atalho, apenas exporto a versão reutilizada e você muda o título no PageHeader.
  return <MilhasLivelo />;
}