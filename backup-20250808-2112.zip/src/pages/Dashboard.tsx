import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export default function Dashboard() {
  /* ── dados mock ───────────────────────────── */
  const resumo = {
    saldo: 7532,
    receitas: 12400,
    despesas: 4868,
    contasAVencer: 1200,
  };

  const despesasPorCategoria = [
    { name: 'Alimentação', value: 1800 },
    { name: 'Moradia', value: 1300 },
    { name: 'Transporte', value: 950 },
    { name: 'Lazer', value: 818 },
  ];

  const receitasVsDespesas = [
    { mes: 'Jan', receitas: 4500, despesas: 2300 },
    { mes: 'Fev', receitas: 3600, despesas: 1900 },
    { mes: 'Mar', receitas: 4300, despesas: 2200 },
    { mes: 'Abr', receitas: 4800, despesas: 2468 },
  ];

  const cores = ['#34D399', '#60A5FA', '#F472B6', '#FCD34D'];

  return (
    <div className="space-y-10">
      <h1 className="text-3xl font-bold mb-4">📊 Dashboard Financeira</h1>

      {/* ---- Cards ---- */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <ResumoCard titulo="💰 Saldo Total"      valor={resumo.saldo}      classNameExtra="bg-green-600" />
        <ResumoCard titulo="📈 Total de Receitas" valor={resumo.receitas}  classNameExtra="bg-blue-600"  />
        <ResumoCard titulo="📉 Total de Despesas" valor={resumo.despesas}  classNameExtra="bg-red-600"   />
        <ResumoCard titulo="⏳ Contas a Vencer"   valor={resumo.contasAVencer} classNameExtra="bg-yellow-500" />
      </div>

      {/* ---- Gráficos ---- */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        {/* Pizza */}
        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="text-lg font-semibold mb-4">📊 Despesas por Categoria</h2>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={despesasPorCategoria}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={90}
                label
              >
                {despesasPorCategoria.map((_, i) => (
                  <Cell key={i} fill={cores[i % cores.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Barras */}
        <div className="bg-white rounded-xl shadow p-4">
          <h2 className="text-lg font-semibold mb-4">📈 Receitas vs Despesas (Mensal)</h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={receitasVsDespesas}>
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="receitas" fill="#3B82F6" />
              <Bar dataKey="despesas" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Cartão de resumo: classes Tailwind fixas
   ──────────────────────────────────────────── */
interface CardProps {
  titulo: string;
  valor: number;
  classNameExtra: string;
}

function ResumoCard({ titulo, valor, classNameExtra }: CardProps) {
  return (
    <div
      className={`w-full h-32 flex flex-col justify-center rounded-xl p-4 text-white shadow-lg border border-white/10 ${classNameExtra}`}
    >
      <h2 className="text-sm font-medium">{titulo}</h2>
      <p className="text-2xl font-bold mt-2">R$ {valor.toFixed(2)}</p>
    </div>
  );
}