export default function FIIs() {
  return <h1 className="text-2xl font-bold">📈 Investimentos - FIIs</h1>;
}