import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { Toaster } from 'sonner';

/* ---------- Contexto de Autenticação ---------- */
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './pages/Login';

/* ---------- Componentes ---------- */
import { Sidebar } from './components/Sidebar';
import { AppHotkeys } from "./components/AppHotkeys";

/* ---------- lazy imports de páginas ---------- */
const Dashboard      = lazy(() => import('./pages/Dashboard'));
const FinancasMensal = lazy(() => import('./pages/FinancasMensal'));
const FinancasAnual  = lazy(() => import('./pages/FinancasAnual'));

// ✅ manter apenas a página em PT-BR
const Investimentos  = lazy(() => import('./pages/Investimentos'));

const RendaFixa = lazy(() => import('./pages/RendaFixa'));
const FIIs      = lazy(() => import('./pages/FIIs'));
const Bolsa     = lazy(() => import('./pages/Bolsa'));
const Cripto    = lazy(() => import('./pages/Cripto'));

const Metas = lazy(() => import('./pages/Metas'));

const MilhasLivelo = lazy(() => import('./pages/MilhasLivelo'));
const MilhasLatam  = lazy(() => import('./pages/MilhasLatam'));
const MilhasAzul   = lazy(() => import('./pages/MilhasAzul'));

const ListaDesejos = lazy(() => import('./pages/ListaDesejos'));
const ListaCompras = lazy(() => import('./pages/ListaCompras'));

const Configuracoes = lazy(() => import('./pages/Configuracoes'));

/* ────────────────────────────────────────────── */

export default function App() {
  return (
    <AuthProvider>
      <Router>
        {/* Toaster global */}
        <Toaster richColors position="top-right" />
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

/* ---------- Rotas protegidas / login ---------- */
function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) return <p className="p-6">Carregando sessão…</p>;
  if (!user)   return <Login />;

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 p-6">
        {/* ⬇️ Atalhos globais (g d, g f, g i, g m, g c, Shift+/? para ajuda) */}
        <AppHotkeys />

        <Suspense fallback={<p>Carregando…</p>}>
          <Routes>
            {/* redirect raiz */}
            <Route path="/" element={<Navigate to="/dashboard" />} />

            {/* Dashboard */}
            <Route path="/dashboard" element={<Dashboard />} />

            {/* Finanças */}
            <Route path="/financas/mensal" element={<FinancasMensal />} />
            <Route path="/financas/anual"  element={<FinancasAnual />} />

            {/* Investimentos */}
            <Route path="/investimentos"               element={<Investimentos />} />
            {/* (opcional) redireciona /investments → /investimentos */}
            <Route path="/investments" element={<Navigate to="/investimentos" replace />} />
            <Route path="/investimentos/renda-fixa"    element={<RendaFixa />} />
            <Route path="/investimentos/fiis"          element={<FIIs />} />
            <Route path="/investimentos/bolsa"         element={<Bolsa />} />
            <Route path="/investimentos/cripto"        element={<Cripto />} />

            {/* Metas & Projetos */}
            <Route path="/metas" element={<Metas />} />

            {/* Milhas */}
            <Route path="/milhas/livelo"    element={<MilhasLivelo />} />
            <Route path="/milhas/latampass" element={<MilhasLatam />} />
            <Route path="/milhas/azul"      element={<MilhasAzul />} />

            {/* Listas */}
            <Route path="/lista-desejos" element={<ListaDesejos />} />
            <Route path="/lista-compras" element={<ListaCompras />} />

            {/* Configurações */}
            <Route path="/configuracoes" element={<Configuracoes />} />

            {/* 404 */}
            <Route path="*" element={<h1>Página não encontrada (404)</h1>} />
          </Routes>
        </Suspense>
      </main>
    </div>
  );
}