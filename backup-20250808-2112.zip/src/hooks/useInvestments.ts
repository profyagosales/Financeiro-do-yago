// src/hooks/useInvestments.ts
import { useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { supabase } from '@/lib/supabaseClient';

export type Investment = {
  id: number;
  user_id: string;
  asset: string;             // ex.: 'CDB Banco X'
  type: 'Renda Fixa' | 'FII' | 'Ação' | 'Cripto';
  quantity: number;
  price: number;             // preço unitário
  date: string;              // YYYY-MM-DD (data do aporte)
};

type NewInvestment = Omit<Investment, 'id' | 'user_id'>;

export function useInvestments(mes?: string) {
  const [data, setData] = useState<Investment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function fetchAll() {
    setLoading(true);
    setError(null);
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id;
    if (!uid) { setData([]); setLoading(false); return; }

    let query = supabase.from('investments').select('*').eq('user_id', uid).order('date', { ascending: false });

    if (mes) {
      const start = dayjs(mes + '-01').startOf('month').format('YYYY-MM-DD');
      const end = dayjs(mes + '-01').endOf('month').format('YYYY-MM-DD');
      query = query.gte('date', start).lte('date', end);
    }

    const { data: rows, error } = await query;
    if (error) setError(error.message);
    setData(rows ?? []);
    setLoading(false);
  }

  useEffect(() => { fetchAll(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [mes]);

  const add = async (payload: NewInvestment) => {
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id!;
    const { error } = await supabase.from('investments').insert({ ...payload, user_id: uid });
    if (error) throw error;
    await fetchAll();
  };

  const update = async (id: number, payload: NewInvestment) => {
    const { error } = await supabase.from('investments').update(payload).eq('id', id);
    if (error) throw error; await fetchAll();
  };

  const remove = async (id: number) => {
    const { error } = await supabase.from('investments').delete().eq('id', id);
    if (error) throw error; await fetchAll();
  };

  return { data, loading, error, add, update, remove };
}