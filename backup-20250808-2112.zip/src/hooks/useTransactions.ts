import { useEffect, useState, useCallback } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../contexts/AuthContext';

export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: number;
  date: string;
  description: string;
  value: number;
  type: TransactionType;
  category: string;
  payment_method: string;
  user_id: string;
}

export function useTransactions(month: string, category: string) {
  const { user } = useAuth();                  // ←  pega uid
  const [data, setData] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  /* ---------- LISTAR ---------- */
  const fetchAll = useCallback(async () => {
    if (!user) return;                         // sem usuário? não carrega
    setLoading(true);
    let q = supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user)                     // ← filtro dono
      .order('date', { ascending: true });

    if (month) q = q.gte('date', `${month}-01`).lte('date', `${month}-31`);
    if (category !== 'Todas') q = q.eq('category', category);

    const { data: rows, error } = await q;
    if (error) setError(error.message);
    else setData(rows as Transaction[]);
    setLoading(false);
  }, [user, month, category]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  /* ---------- ADICIONAR ---------- */
  const add = useCallback(
    async (t: Omit<Transaction, 'id' | 'user_id'>) => {
      if (!user) return;
      const { data: row, error } = await supabase
        .from('transactions')
        .insert({ ...t, user_id: user })       // ← grava dono
        .select()
        .single();
      if (error) throw error;
      setData(prev => [...prev, row as Transaction]);
    },
    [user],
  );

  /* ---------- EDITAR ---------- */
  const update = useCallback(
    async (id: number, changes: Partial<Transaction>) => {
      const { data: row, error } = await supabase
        .from('transactions')
        .update(changes)
        .eq('id', id)
        .eq('user_id', user);
      if (error) throw error;
      setData(prev => prev.map(t => (t.id === id ? (row as Transaction) : t)));
    },
    [user],
  );

  /* ---------- EXCLUIR ---------- */
  const remove = useCallback(
    async (id: number) => {
      const { error } = await supabase
        .from('transactions')
        .delete()
        .eq('id', id)
        .eq('user_id', user);
      if (error) throw error;
      setData(prev => prev.filter(t => t.id !== id));
    },
    [user],
  );

  return { data, loading, error, add, update, remove, refetch: fetchAll };
}