import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';

type BaseData = {
  date: string;            // YYYY-MM-DD
  description: string;
  value: number;           // positivo
  type: 'income' | 'expense';
  category: string;
  payment_method?: string;
};

type Props = {
  open: boolean;
  onClose: () => void;
  initialData?: BaseData | null;
  onSubmit: (data: BaseData) => Promise<void> | void;
};

const CATEGORIAS = ['Alimentação','Transporte','Moradia','Educação','Saúde','Lazer','Salário','Freelance','Investimentos','Outros'];
const METODOS = ['Pix','Cartão','Dinheiro','Boleto','Transferência','Outro'];

export function ModalTransacao({ open, onClose, initialData, onSubmit }: Props) {
  const [form, setForm] = useState<BaseData>({
    date: new Date().toISOString().slice(0,10),
    description: '',
    value: 0,
    type: 'expense',
    category: 'Outros',
    payment_method: 'Outro',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialData) setForm(initialData);
    else setForm((f) => ({ ...f, date: new Date().toISOString().slice(0,10) }));
  }, [initialData, open]);

  const handleChange = (key: keyof BaseData, v: any) => setForm(prev => ({ ...prev, [key]: v }));

  const handleSubmit = async () => {
    if (!form.description || !form.date || !form.category || !form.type) return;
    if (Number.isNaN(Number(form.value))) return;
    setLoading(true);
    try {
      await onSubmit({ ...form, value: Number(form.value) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Editar Transação' : 'Nova Transação'}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-1">
            <Label>Data</Label>
            <Input
              type="date"
              value={form.date}
              onChange={(e) => handleChange('date', e.target.value)}
            />
          </div>

          <div className="grid gap-1">
            <Label>Descrição</Label>
            <Input
              placeholder="Ex.: Mercado, Salário..."
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
            />
          </div>

          <div className="grid gap-1">
            <Label>Valor (R$)</Label>
            <Input
              type="number"
              step="0.01"
              inputMode="decimal"
              value={form.value}
              onChange={(e) => handleChange('value', e.target.value)}
            />
            <span className="text-xs text-slate-500">Sempre valor positivo — o tipo define se é receita ou despesa.</span>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="grid gap-1">
              <Label>Tipo</Label>
              <Select value={form.type} onValueChange={(v: 'income' | 'expense') => handleChange('type', v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="expense">Despesa</SelectItem>
                  <SelectItem value="income">Receita</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-1">
              <Label>Categoria</Label>
              <Select value={form.category} onValueChange={(v) => handleChange('category', v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {CATEGORIAS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-1">
            <Label>Método de pagamento</Label>
            <Select value={form.payment_method} onValueChange={(v) => handleChange('payment_method', v)}>
              <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent>
                {METODOS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={loading}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? 'Salvando…' : 'Salvar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}