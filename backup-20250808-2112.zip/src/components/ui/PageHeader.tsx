import { Bell, Sun, Moon } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useEffect, useState } from 'react';

export function PageHeader({ title }:{title:string}) {
  const [dark, setDark] = useState(()=>localStorage.getItem('fy_theme')==='dark');
  useEffect(()=>{
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('fy_theme', dark ? 'dark' : 'light');
  },[dark]);

  return (
    <div className="rounded-b-card p-6 bg-fy-header text-white mb-6 flex items-center justify-between">
      <h1 className="text-2xl font-semibold">{title}</h1>
      <div className="flex items-center gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger className="p-2 rounded-full bg-white/10 hover:bg-white/20">
              <Bell size={18}/>
            </TooltipTrigger>
            <TooltipContent>Notificações</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <button
          onClick={()=>setDark(s=>!s)}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20"
          aria-label="Alternar tema"
        >
          {dark ? <Sun size={18}/> : <Moon size={18}/>}
        </button>
      </div>
    </div>
  );
}