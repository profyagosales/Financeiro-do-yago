// src/components/Sidebar.tsx
import * as React from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Wallet,
  CalendarRange,
  PiggyBank,
  Landmark,
  Building2,
  CandlestickChart,
  Coins,
  Target,
  Plane,
  Gift,
  ShoppingCart,
  Settings,
  ChevronDown,
} from "lucide-react";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle"; // <- NOVO

type Item = { label: string; to: string; icon?: React.ElementType };
type Section = { label: string; items: (Item | { label: string; icon?: React.ElementType; children: Item[] })[] };

const sections: Section[] = [
  {
    label: "Geral",
    items: [
      { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
      {
        label: "Finanças",
        icon: Wallet,
        children: [
          { label: "Mensal", to: "/financas/mensal", icon: CalendarRange },
          { label: "Anual", to: "/financas/anual", icon: CalendarRange },
        ],
      },
    ],
  },
  {
    label: "Investimentos",
    items: [
      { label: "Resumo", to: "/investimentos", icon: PiggyBank },
      {
        label: "Carteira",
        icon: Landmark,
        children: [
          { label: "Renda Fixa", to: "/investimentos/renda-fixa", icon: Landmark },
          { label: "FIIs", to: "/investimentos/fiis", icon: Building2 },
          { label: "Bolsa", to: "/investimentos/bolsa", icon: CandlestickChart },
          { label: "Cripto", to: "/investimentos/cripto", icon: Coins },
        ],
      },
    ],
  },
  {
    label: "Planejamento",
    items: [
      { label: "Metas e Projetos", to: "/metas", icon: Target },
      {
        label: "Milhas",
        icon: Plane,
        children: [
          { label: "Livelo", to: "/milhas/livelo", icon: Plane },
          { label: "Latam Pass", to: "/milhas/latampass", icon: Plane },
          { label: "Azul", to: "/milhas/azul", icon: Plane },
        ],
      },
      { label: "Lista de Desejos", to: "/lista-desejos", icon: Gift },
      { label: "Lista de Compras", to: "/lista-compras", icon: ShoppingCart },
    ],
  },
  {
    label: "Sistema",
    items: [{ label: "Configurações", to: "/configuracoes", icon: Settings }],
  },
];

export const Sidebar: React.FC = () => {
  const location = useLocation();
  const [open, setOpen] = React.useState<Record<string, boolean>>({});

  // Abre automaticamente a seção que contém a rota atual
  React.useEffect(() => {
    const next: Record<string, boolean> = {};
    sections.forEach((sec) => {
      sec.items.forEach((it) => {
        if ("children" in (it as any)) {
          const group = it as any;
          const activeChild = group.children.some((c: Item) => location.pathname.startsWith(c.to));
          if (activeChild) next[group.label] = true;
        }
      });
    });
    setOpen((p) => ({ ...p, ...next }));
  }, [location.pathname]);

  return (
    <aside className="sticky top-0 h-screen w-72 shrink-0 border-r border-slate-800 bg-slate-950/95 backdrop-blur text-slate-200">
      {/* Brand + Theme */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-800">
        <Logo />
        <div className="flex flex-col">
          <span className="text-sm uppercase tracking-widest text-emerald-400/90">Financeiro</span>
          <span className="text-lg font-semibold text-white">do Yago</span>
        </div>
        <div className="ml-auto">
          <ThemeToggle /> {/* <- botão de tema */}
        </div>
      </div>

      {/* Nav */}
      <nav className="px-2 py-3 overflow-y-auto h-[calc(100vh-64px)]">
        {sections.map((section) => (
          <div key={section.label} className="mt-5 first:mt-0">
            <div className="px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-slate-400/70">
              {section.label}
            </div>

            <ul className="space-y-1">
              {section.items.map((item) => {
                if ("children" in (item as any)) {
                  const group = item as any;
                  const Icon = group.icon ?? Wallet;
                  const isOpen = !!open[group.label];
                  return (
                    <li key={group.label}>
                      <button
                        onClick={() => setOpen((p) => ({ ...p, [group.label]: !isOpen }))}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-slate-300 hover:bg-white/5 hover:text-white transition"
                      >
                        <span className="flex items-center gap-3">
                          <Icon className="h-4 w-4 text-slate-400" />
                          <span className="text-sm font-medium">{group.label}</span>
                        </span>
                        <ChevronDown
                          className={`h-4 w-4 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                      {isOpen && (
                        <ul className="mt-1 space-y-1 pl-8">
                          {group.children.map((child: Item) => (
                            <NavItem key={child.to} to={child.to} icon={child.icon} label={child.label} />
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                }
                return (
                  <li key={item.to}>
                    <NavItem to={item.to} icon={item.icon} label={item.label} />
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
};

function NavItem({ to, icon: Icon, label }: Item) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        [
          "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition",
          isActive
            ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30"
            : "text-slate-300 hover:text-white hover:bg-white/5",
        ].join(" ")
      }
    >
      {Icon ? (
        <Icon className="h-4 w-4 text-slate-400 group-[.bg-emerald-500\\/15]:text-emerald-300 group-hover:text-white" />
      ) : null}
      <span>{label}</span>
    </NavLink>
  );
}