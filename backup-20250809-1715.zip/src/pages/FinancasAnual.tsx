export default function FinancasAnual() {
  return <h1 className="text-2xl font-bold">💰 Finanças - Anual</h1>;
}