export default function ListaCompras() {
  return <h1 className="text-2xl font-bold">🧾 Lista de Compras</h1>;
}