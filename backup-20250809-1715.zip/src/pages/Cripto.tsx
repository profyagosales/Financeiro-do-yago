export default function Cripto() {
  return <h1 className="text-2xl font-bold">📈 Investimentos - Criptomoedas</h1>;
}