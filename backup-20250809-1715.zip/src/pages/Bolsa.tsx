export default function Bolsa() {
  return <h1 className="text-2xl font-bold">📈 Investimentos - Bolsa Brasileira</h1>;
}