export default function Configuracoes() {
  return <h1 className="text-2xl font-bold">⚙️ Configurações</h1>;
}